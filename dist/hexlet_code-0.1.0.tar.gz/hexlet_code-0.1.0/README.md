Installation and gameplay demos.
1. Brain-even installation and and gameplay demonstration
[![asciicast](https://asciinema.org/a/HTe6v1FgYYpdWXEsT3SsM0NZQ.svg)](https://asciinema.org/a/HTe6v1FgYYpdWXEsT3SsM0NZQ)

3. Brain-calc installation and and gameplay demonstration
[![asciicast](https://asciinema.org/a/647245.svg)](https://asciinema.org/a/647245)

4. Brain-gcd gameplay demonstration
[![asciicast](https://asciinema.org/a/647390.svg)](https://asciinema.org/a/647390)

5. Brain-progression gameplay demonstration
[![asciicast](https://asciinema.org/a/647402.svg)](https://asciinema.org/a/647402)

6. Brain-prime gameplay demonstration
[![asciicast](https://asciinema.org/a/647450.svg)](https://asciinema.org/a/647450)

### Hexlet tests and linter status:
[![Actions Status](https://github.com/fiftinmen/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/fiftinmen/python-project-49/actions)
